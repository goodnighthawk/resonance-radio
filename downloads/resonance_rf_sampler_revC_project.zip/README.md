# Resonance RF Sampler Rev C
Design target: 50-ohm dummy load + selectable nominal -40/-50/-60 dB sample output for a 50-ohm SDR input.

Target series resistors:
-40 dB: 4.99 kOhm (calculated 40.07 dB)
-50 dB: 15.8 kOhm (50.02 dB)
-60 dB: 49.9 kOhm (59.99 dB)

Input load: 2x 100 Ohm, 1 W, 1% metal-film in parallel.
Output: 1 uF film DC block, optional anti-parallel 1N5711 clamps, SMA/bulkhead wiring pads.
Board target: 65 x 35 mm, 2-layer FR4, solid ground plane, 4x M3 mounting holes.
Switch: external 2P3T rotary selector; one pole used for range selection, second pole reserved.
Always start measurements at -60 dB. Calibrate each finished range with a known RF source before quoting absolute attenuation.
