from kicad_sch_api import Schematic
OUT='/home/arpeggi4/rf-sampler-kicad/resonance_rf_sampler_revC.kicad_sch'
s=Schematic.create('resonance_rf_sampler_revC')
s.set_title_block(title='Resonance RF Sampler / Attenuator Rev C', date='2026-09-27', rev='C', company='Resonance Radio', comments={1:'50 ohm dummy load + selectable nominal -40/-50/-60 dB sample output',2:'External 2P3T rotary selector connects one TAP to SEL_COM'})
A=s.components.add
A('Connector_Generic:Conn_01x02',reference='J1',value='PANEL RF IN',position=(20,50),rotation=180,footprint='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical')
A('Device:R',reference='R1',value='100R 1W',position=(42,72),footprint='Resistor_THT:R_Axial_DIN0411_L9.9mm_D3.6mm_P15.24mm_Horizontal')
A('Device:R',reference='R2',value='100R 1W',position=(56,72),footprint='Resistor_THT:R_Axial_DIN0411_L9.9mm_D3.6mm_P15.24mm_Horizontal')
A('Device:R',reference='R3',value='4.99k 1%',position=(65,47),rotation=270,footprint='Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal')
A('Device:R',reference='R4',value='15.8k 1%',position=(65,50),rotation=270,footprint='Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal')
A('Device:R',reference='R5',value='49.9k 1%',position=(65,53),rotation=270,footprint='Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal')
A('Connector_Generic:Conn_01x04',reference='J3',value='2P3T SELECTOR',position=(105,50),rotation=0,footprint='Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical')
A('Device:C',reference='C1',value='1uF FILM >=25V',position=(125,55),rotation=270,footprint='Capacitor_THT:C_Rect_L19.0mm_W5.0mm_P15.00mm_MKS4')
A('Connector_Generic:Conn_01x02',reference='J2',value='PANEL SDR OUT',position=(150,55),rotation=0,footprint='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical')
A('Device:D_Schottky',reference='D1',value='1N5711 OPTIONAL',position=(130,72),rotation=90,footprint='Diode_THT:D_DO-35_SOD27_P10.16mm_Horizontal')
A('Device:D_Schottky',reference='D2',value='1N5711 OPTIONAL',position=(140,72),rotation=270,footprint='Diode_THT:D_DO-35_SOD27_P10.16mm_Horizontal')
# Nets are drawn pin-to-pin so ERC can verify every component terminal.
def route(a,pa,b,pb):
    return s.auto_route_pins(a,str(pa),b,str(pb),'manhattan')
# RF input bus
route('J1',1,'R1',1); route('R1',1,'R2',1); route('R2',1,'R3',1); route('R3',1,'R4',1); route('R4',1,'R5',1)
# 50-ohm dummy load and common ground return
route('J1',2,'R1',2); route('R1',2,'R2',2); route('R2',2,'D1',2); route('D1',2,'D2',1); route('D2',1,'J2',2)
# selectable attenuation taps
route('R3',2,'J3',1); route('R4',2,'J3',2); route('R5',2,'J3',3)
# selector common -> DC block -> SDR output
route('J3',4,'C1',1); route('C1',2,'J2',1)
# optional anti-parallel protection clamps
route('J2',1,'D1',1); route('D1',1,'D2',2)
# Explanatory text only; electrical connectivity is in the wires above.
s.add_text('RF INPUT / 50 ohm LOAD',position=(28,37),size=1.5,bold=True)
s.add_text('Nominal -40 dB',position=(77,45),size=1.2)
s.add_text('Nominal -50 dB',position=(77,50),size=1.2)
s.add_text('Nominal -60 dB',position=(77,55),size=1.2)
s.add_text('External 2P3T selector',position=(95,37),size=1.4,bold=True)
s.add_text('DC block + SDR output',position=(120,37),size=1.4,bold=True)
s.add_text('D1/D2 optional emergency clamps; omit for best linearity.',position=(112,84),size=1.1)
s.save_as(OUT)
print('saved',OUT)
print(s.get_statistics())
for ref in ['J1','R1','R2','R3','R4','R5','J3','C1','J2','D1','D2']:
    print(ref,s.list_component_pins(ref))
