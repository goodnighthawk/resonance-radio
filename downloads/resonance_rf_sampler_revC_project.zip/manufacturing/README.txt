Resonance RF Sampler / Attenuator Rev C

Board: 65 x 35 mm, 2-layer FR4, 1.6 mm
Mounting: 4 x M3 (3.2 mm NPTH)
Input load: 2 x 100 ohm, 1 W, 1% in parallel = 50 ohm nominal
Selectable sample resistors: 4.99 kOhm / 15.8 kOhm / 49.9 kOhm
Nominal sample ranges into 50 ohm SDR: -40.07 / -50.02 / -59.99 dB
C1: 1 uF film DC block, >=25 V
D1/D2: optional 1N5711 anti-parallel emergency clamps
External selector: 2P3T rotary switch; J3 silkscreen labels -40/-50/-60/COM

Validation:
ERC: 0 errors, 0 warnings
DRC: 0 violations, 0 unconnected pads

Measurement rule: begin at -60 dB and calibrate each assembled range before quoting absolute attenuation.
