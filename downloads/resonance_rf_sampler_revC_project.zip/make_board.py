import pcbnew, os
MM=pcbnew.FromMM
OUT='/home/arpeggi4/rf-sampler-kicad/resonance_rf_sampler_revC.kicad_pcb'
b=pcbnew.BOARD(); b.GetDesignSettings().SetBoardThickness(MM(1.6))
# nets
nets={}
for name in ['GND','RF_IN','TAP40','TAP50','TAP60','SEL_COM','SDR_OUT']:
    n=pcbnew.NETINFO_ITEM(b,name); b.Add(n); nets[name]=n

def fp(lib,name,ref,val,x,y,rot=0):
    p=pcbnew.FootprintLoad('/usr/share/kicad/footprints/'+lib+'.pretty',name)
    if p is None: raise RuntimeError(f'footprint {lib}:{name} not found')
    p.SetReference(ref); p.SetValue(val); p.Reference().SetVisible(False); p.Value().SetVisible(False); p.SetPosition(pcbnew.VECTOR2I(MM(x),MM(y))); p.SetOrientationDegrees(rot); b.Add(p); return p

def assign(p,m):
    for pad in p.Pads():
        num=str(pad.GetNumber())
        if num in m: pad.SetNet(nets[m[num]])

def pos(p,num):
    return p.FindPadByNumber(str(num)).GetPosition()

def track(a,c,net,width=0.8,layer=pcbnew.F_Cu):
    t=pcbnew.PCB_TRACK(b); t.SetLayer(layer); t.SetStart(a); t.SetEnd(c); t.SetWidth(MM(width)); t.SetNet(nets[net]); b.Add(t)

def via_point(x,y,net,drill=0.4,size=0.8):
    v=pcbnew.PCB_VIA(b); v.SetPosition(pcbnew.VECTOR2I(MM(x),MM(y))); v.SetDrill(MM(drill)); v.SetWidth(MM(size)); v.SetNet(nets[net]); b.Add(v); return v
print('stage footprints', flush=True)
# footprints / placement on 65 x 35 mm board
J1=fp('Connector_PinHeader_2.54mm','PinHeader_1x02_P2.54mm_Vertical','J1','PANEL RF IN',5,16.2)
J2=fp('Connector_PinHeader_2.54mm','PinHeader_1x02_P2.54mm_Vertical','J2','PANEL SDR OUT',60,16.2)
J3=fp('Connector_PinHeader_2.54mm','PinHeader_1x04_P2.54mm_Vertical','J3','2P3T SELECTOR',38,8)
R1=fp('Resistor_THT','R_Axial_DIN0411_L9.9mm_D3.6mm_P15.24mm_Horizontal','R1','100R 1W',10,24)
R2=fp('Resistor_THT','R_Axial_DIN0411_L9.9mm_D3.6mm_P15.24mm_Horizontal','R2','100R 1W',10,30)
R3=fp('Resistor_THT','R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal','R3','4.99k 1%',12,7)
R4=fp('Resistor_THT','R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal','R4','15.8k 1%',12,11)
R5=fp('Resistor_THT','R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal','R5','49.9k 1%',12,15)
C1=fp('Capacitor_THT','C_Rect_L19.0mm_W5.0mm_P15.00mm_MKS4','C1','1uF FILM >=25V',35,22.5)
D1=fp('Diode_THT','D_DO-35_SOD27_P10.16mm_Horizontal','D1','1N5711 OPTIONAL',43,28)
D2=fp('Diode_THT','D_DO-35_SOD27_P10.16mm_Horizontal','D2','1N5711 OPTIONAL',30,30)
assign(J1,{'1':'RF_IN','2':'GND'}); assign(J2,{'1':'SDR_OUT','2':'GND'})
assign(J3,{'1':'TAP40','2':'TAP50','3':'TAP60','4':'SEL_COM'})
assign(R1,{'1':'RF_IN','2':'GND'}); assign(R2,{'1':'RF_IN','2':'GND'})
assign(R3,{'1':'RF_IN','2':'TAP40'}); assign(R4,{'1':'RF_IN','2':'TAP50'}); assign(R5,{'1':'RF_IN','2':'TAP60'})
assign(C1,{'1':'SEL_COM','2':'SDR_OUT'})
assign(D1,{'1':'SDR_OUT','2':'GND'}); assign(D2,{'1':'GND','2':'SDR_OUT'})
for i,(x,y) in enumerate([(3.5,3.5),(61.5,3.5),(3.5,31.5),(61.5,31.5)],1):
    fp('MountingHole','MountingHole_3.2mm_M3',f'H{i}','M3',x,y)
P=lambda x,y: pcbnew.VECTOR2I(MM(x),MM(y))
# RF input bus and branches
track(pos(J1,1),P(10,16.2),'RF_IN')
track(P(10,7),P(10,30),'RF_IN')
for r in (R3,R4,R5): track(P(10,pcbnew.ToMM(pos(r,1).y)),pos(r,1),'RF_IN')
track(P(10,24),pos(R1,1),'RF_IN'); track(P(10,30),pos(R2,1),'RF_IN')
# selectable taps: short orthogonal routes to selector header
for r,pin in [(R3,1),(R4,2),(R5,3)]:
    rp=pos(r,2); jp=pos(J3,pin); mid=P(30,pcbnew.ToMM(rp.y)); track(rp,mid,{1:'TAP40',2:'TAP50',3:'TAP60'}[pin]); track(mid,P(30,pcbnew.ToMM(jp.y)),{1:'TAP40',2:'TAP50',3:'TAP60'}[pin]); track(P(30,pcbnew.ToMM(jp.y)),jp,{1:'TAP40',2:'TAP50',3:'TAP60'}[pin])
# selector common through DC block
track(pos(J3,4),P(38,22.5),'SEL_COM'); track(P(38,22.5),pos(C1,1),'SEL_COM')
# output network routed clear of J2 ground pad
track(pos(C1,2),P(57,22.5),'SDR_OUT'); track(P(57,22.5),P(63,22.5),'SDR_OUT'); track(P(63,22.5),P(63,16.2),'SDR_OUT'); track(P(63,16.2),pos(J2,1),'SDR_OUT')
track(pos(D1,1),P(40.5,28),'SDR_OUT'); track(P(40.5,28),P(40.5,26),'SDR_OUT'); track(P(40.5,26),P(57,26),'SDR_OUT'); track(P(57,26),P(57,22.5),'SDR_OUT')
track(pos(D2,2),P(57,30),'SDR_OUT'); track(P(57,30),P(57,22.5),'SDR_OUT')
# explicit bottom-side ground spine; the B.Cu zone supplements this when refilled in KiCad
track(pos(J1,2),P(7,pcbnew.ToMM(pos(J1,2).y)),'GND',0.8,pcbnew.B_Cu); track(P(7,pcbnew.ToMM(pos(J1,2).y)),P(7,33.5),'GND',0.8,pcbnew.B_Cu)
track(P(7,33.5),P(58,33.5),'GND',0.8,pcbnew.B_Cu)
for gp in [pos(R1,2),pos(R2,2),pos(D2,1)]: track(gp,P(pcbnew.ToMM(gp.x),33.5),'GND',0.8,pcbnew.B_Cu)
track(pos(D1,2),P(55,28),'GND',0.8,pcbnew.B_Cu); track(P(55,28),P(55,33.5),'GND',0.8,pcbnew.B_Cu)
track(pos(J2,2),P(58,pcbnew.ToMM(pos(J2,2).y)),'GND',0.8,pcbnew.B_Cu); track(P(58,pcbnew.ToMM(pos(J2,2).y)),P(58,33.5),'GND',0.8,pcbnew.B_Cu)
# board outline
for a,c in [((0,0),(65,0)),((65,0),(65,35)),((65,35),(0,35)),((0,35),(0,0))]:
    q=pcbnew.PCB_SHAPE(b); q.SetShape(pcbnew.SHAPE_T_SEGMENT); q.SetLayer(pcbnew.Edge_Cuts); q.SetStart(P(*a)); q.SetEnd(P(*c)); q.SetWidth(MM(0.05)); b.Add(q)
# bottom ground plane definition
z=pcbnew.ZONE(b); z.SetLayer(pcbnew.B_Cu); z.SetNet(nets['GND']); poly=z.Outline(); poly.NewOutline()
for x,y in [(0.5,0.5),(64.5,0.5),(64.5,34.5),(0.5,34.5)]: poly.Append(MM(x),MM(y))
b.Add(z)
# minimal silkscreen markings
for text,x,y,size in [('RF IN',4.5,14,1.0),('SDR OUT',57.5,14,1.0),('Rev C',31,2.5,1.0),('-40',44,8,0.8),('-50',44,10.54,0.8),('-60',44,13.08,0.8),('COM',44,15.62,0.8),('START -60 dB',47,18.5,0.8)]:
    q=pcbnew.PCB_TEXT(b); q.SetText(text); q.SetLayer(pcbnew.F_SilkS); q.SetPosition(P(x,y)); q.SetTextSize(P(size,size)); q.SetTextThickness(MM(0.14)); b.Add(q)
pcbnew.SaveBoard(OUT,b)
# Re-load before zone fill; KiCad 9 SWIG is more stable this way.
b2=pcbnew.LoadBoard(OUT)
filler=pcbnew.ZONE_FILLER(b2)
filler.Fill(b2.Zones())
pcbnew.SaveBoard(OUT,b2)
print('saved+filled',OUT,'footprints',len(list(b2.GetFootprints())),'tracks',len(list(b2.GetTracks())),'zones',len(b2.Zones()), flush=True)
